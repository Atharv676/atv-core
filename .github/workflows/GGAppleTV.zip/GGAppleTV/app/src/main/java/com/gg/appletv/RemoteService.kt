package com.gg.appletv
import android.app.*
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.IBinder
import dadb.AdbKeyPair
import dadb.Dadb
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.net.URLDecoder
import java.util.concurrent.Executors

class RemoteService : Service() {
    private var server: Web? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val ch = "gg"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(ch, "GG Apple TV", NotificationManager.IMPORTANCE_LOW))
        val n = (if (android.os.Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this))
            .setContentTitle("GG Apple TV remote running").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n)
        if (server == null) {
            try { server = Web(this).also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) } } catch (_: Exception) {}
        }
        return START_STICKY
    }
    override fun onDestroy() { server?.stop(); super.onDestroy() }

    companion object {
        fun localIp(c: Context): String {
            val ip = (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo.ipAddress
            return if (ip == 0) "FIRE-TV-IP" else "${ip and 255}.${ip shr 8 and 255}.${ip shr 16 and 255}.${ip shr 24 and 255}"
        }
    }
}

class Web(private val ctx: Context) : NanoHTTPD(8080) {
    private val pool = Executors.newSingleThreadExecutor()
    @Volatile private var adb: Dadb? = null
    @Volatile var lastError = ""

    private fun keys(): AdbKeyPair {
        val priv = File(ctx.filesDir, "adbkey"); val pub = File(ctx.filesDir, "adbkey.pub")
        if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
        return AdbKeyPair.read(priv, pub)
    }
    private fun connect(): Dadb {
        adb?.let { return it }
        val kp = keys()
        var err: Exception? = null
        for (h in listOf("127.0.0.1", RemoteService.localIp(ctx))) {
            try { val d = Dadb.create(h, 5555, kp); d.shell("echo ok"); adb = d; return d } catch (e: Exception) { err = e }
        }
        throw err ?: RuntimeException("ADB connect failed")
    }
    private fun sh(cmd: String): String = try {
        val r = pool.submit<String> {
            try { connect().shell(cmd).allOutput }
            catch (e: Exception) { try { adb?.close() } catch (_: Exception) {}; adb = null; connect().shell(cmd).allOutput }
        }.get(); lastError = ""; r
    } catch (e: Exception) { lastError = e.cause?.message ?: e.message ?: "error"; "ERR: $lastError" }

    override fun serve(s: IHTTPSession): Response {
        val u = s.uri
        fun txt(t: String) = newFixedLengthResponse(Response.Status.OK, "text/plain", t)
        return when {
            u.startsWith("/key/") -> { val c = u.removePrefix("/key/").toIntOrNull()
                if (c == null) txt("bad") else txt(sh("input keyevent $c")) }
            u.startsWith("/long/") -> { val c = u.removePrefix("/long/").toIntOrNull()
                if (c == null) txt("bad") else txt(sh("input keyevent --longpress $c")) }
            u == "/text" -> { val t = s.parameters["t"]?.firstOrNull() ?: ""
                val e = t.replace(" ", "%s").replace(Regex("[^A-Za-z0-9%._@-]")) { "\\" + it.value }
                txt(sh("input text \"$e\"")) }
            u.startsWith("/app/") -> { val p = URLDecoder.decode(u.removePrefix("/app/"), "UTF-8")
                if (!Regex("[A-Za-z0-9._]+").matches(p)) txt("bad")
                else txt(sh("monkey -p $p -c android.intent.category.LAUNCHER 1; monkey -p $p -c android.intent.category.LEANBACK_LAUNCHER 1")) }
            u == "/status" -> txt(sh("echo connected"))
            else -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", PAGE)
        }
    }
}

private val KEYS = listOf(
    "Home" to 3, "Back" to 4, "Menu" to 82, "▲" to 19, "◀" to 21, "OK" to 23, "▶" to 22, "▼" to 20,
    "⏪" to 89, "⏯" to 85, "⏩" to 90, "⏮" to 88, "⏭" to 87, "Vol −" to 25, "Mute" to 164, "Vol +" to 24,
    "Power" to 26)
private val APPS = listOf("Netflix" to "com.netflix.ninja", "YouTube" to "com.amazon.firetv.youtube",
    "Prime" to "com.amazon.avod", "Settings" to "com.amazon.tv.launcher", "AirScreen" to "com.ionitech.airscreen")
private val PAGE: String = """<!doctype html><html><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1,user-scalable=no">
<meta name=apple-mobile-web-app-capable content=yes><meta name=apple-mobile-web-app-title content="GG Apple TV">
<style>body{background:#101418;color:#fff;font-family:-apple-system,sans-serif;text-align:center;margin:0;padding:12px}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;max-width:420px;margin:10px auto}
button{background:#1f2a35;color:#fff;border:0;border-radius:14px;height:60px;font-size:20px;-webkit-user-select:none}
button:active{background:#1E88E5}input{width:62%;height:44px;font-size:18px;border-radius:10px;border:0;padding:0 8px}
#s{font-size:13px;color:#9ab}</style></head><body><h2>GG Apple TV</h2><div id=s>connecting…</div>
<div class=g>${KEYS.joinToString("") { "<button data-k=${it.second}>${it.first}</button>" }}</div>
<div class=g style="grid-template-columns:repeat(3,1fr)">${APPS.joinToString("") { "<button data-a=${it.second}>${it.first}</button>" }}</div>
<p><input id=t placeholder="type text"> <button style="width:30%;height:44px" onclick="f('/text?t='+encodeURIComponent(t.value));t.value=''">Send</button></p>
<script>
function f(u){return fetch(u).then(r=>r.text()).then(x=>{s.textContent=x.startsWith('ERR')?x:'ok';return x}).catch(()=>s.textContent='cannot reach Fire TV')}
document.querySelectorAll('button[data-k]').forEach(b=>{let timer,held;
 const k=b.dataset.k;
 b.addEventListener('touchstart',e=>{e.preventDefault();held=false;f('/key/'+k);navigator.vibrate&&navigator.vibrate(5);
  if([19,20,21,22,24,25].includes(+k))timer=setTimeout(function r(){held=true;f('/key/'+k);timer=setTimeout(r,150)},450)});
 b.addEventListener('touchend',()=>clearTimeout(timer));
 b.addEventListener('mousedown',()=>f('/key/'+k));});
document.querySelectorAll('button[data-a]').forEach(b=>b.onclick=()=>f('/app/'+b.dataset.a));
f('/status');
</script></body></html>"""
