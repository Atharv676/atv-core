package com.gg.appletv
import android.content.*
import androidx.core.content.ContextCompat
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try { ContextCompat.startForegroundService(c, Intent(c, RemoteService::class.java)) } catch (_: Exception) {}
    }
}
