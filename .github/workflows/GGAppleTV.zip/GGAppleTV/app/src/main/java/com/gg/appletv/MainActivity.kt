package com.gg.appletv
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        ContextCompat.startForegroundService(this, Intent(this, RemoteService::class.java))
        val ip = RemoteService.localIp(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101418")); setPadding(60, 60, 60, 60)
        }
        fun tv(t: String, s: Float, c: Int = Color.WHITE) = TextView(this).apply {
            text = t; textSize = s; setTextColor(c); gravity = Gravity.CENTER; setPadding(0, 14, 0, 14)
        }
        col.addView(tv("GG Apple TV", 40f))
        col.addView(tv("Open this on your iPhone (Safari, same Wi-Fi):", 20f, Color.LTGRAY))
        col.addView(tv("http://$ip:8080", 34f, Color.parseColor("#64B5F6")))
        col.addView(tv("Then Share > Add to Home Screen for a remote icon.", 18f, Color.LTGRAY))
        col.addView(tv("First time: accept 'Allow USB debugging' on this TV and tick Always allow.", 18f, Color.YELLOW))
        val btn = Button(this).apply {
            text = "Open AirPlay receiver (AirScreen)"
            setOnClickListener {
                val i = packageManager.getLaunchIntentForPackage("com.ionitech.airscreen")
                if (i != null) startActivity(i) else Toast.makeText(this@MainActivity,
                    "AirScreen is not installed", Toast.LENGTH_LONG).show()
            }
        }
        col.addView(btn)
        setContentView(col)
    }
}
