plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.gg.appletv"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gg.appletv"
        minSdk = 22
        targetSdk = 33
        versionCode = 2
        versionName = "2.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += setOf("META-INF/INDEX.LIST", "META-INF/io.netty.versions.properties") } }
}
dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("dev.mobile:dadb:1.2.7")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
}
